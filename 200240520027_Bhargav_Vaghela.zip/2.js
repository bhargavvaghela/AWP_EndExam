function showdetails(){
    let user = document.querySelector(".usrnm").value;
    let ps = document.querySelector(".pass").value;
    let eml = document.querySelector(".email").value;
    console.log(user);
    console.log(ps);
    console.log(eml);

    let di = document.querySelector(".show");

    if (user == "" || ps == "" || eml == ""){
        alert("Please enter some value");
    }

    if (user == "" || ps == "" || eml == ""){
        di.innerHTML = "";
    }
    else{
        di.innerHTML= "USERNAME = " + user +",   " +"PASSWORD = " + ps + ",   " + "EMAIL-ID = " + eml;
    }
    
    


    
    


   document.querySelector(".usrnm").value="";
   document.querySelector(".pass").value="";
   document.querySelector(".email").value="";
   
}
